DROP TABLE member;
DROP TABLE phone;
DROP TABLE sim;
DROP TABLE group_name;
DROP TABLE  contacts;

/*            LAB 1, 2 ------- CREATE TABLE        */
CREATE TABLE contacts(
  name varchar(20)  not null,
  phone_no varchar(15) not null check(length(phone_no)>=11),
  email varchar(20) default null,
  address varchar(30) default null 
);

CREATE TABLE phone(
  mac_id varchar(20) default '94:92:bc:74:15:d9',
  brand varchar(20) default 'wlaton',
  model varchar(20)  default 'zx2 mini',
  phone_no varchar(15) not null check(length(phone_no)>=11)
);

CREATE TABLE sim (
  sim_no varchar(15) default '01927474577',
  phone_no varchar(15) not null check(length(phone_no)>=11)
);


CREATE table group_name(
  id number not null,
  grp_name varchar(20) 
);



CREATE TABLE member(
   phone_no varchar(15) not null check(length(phone_no)>=11),
   id int not null
);

/*        LAB 3---- PRIMARY KEY, ALTER TABLE          */

ALTER TABLE contacts ADD CONSTRAINT contacts_pk PRIMARY KEY(phone_no);

ALTER TABLE phone ADD CONSTRAINT phone_fk 
  FOREIGN KEY(phone_no) REFERENCES contacts(phone_no) ON DELETE CASCADE;
ALTER TABLE phone ADD CONSTRAINT phone_pk 
  PRIMARY KEY(phone_no) ;

ALTER TABLE sim ADD CONSTRAINT sim_fk 
  FOREIGN KEY(phone_no) REFERENCES contacts(phone_no) ON DELETE CASCADE;
ALTER TABLE sim ADD CONSTRAINT sim_pk 
  PRIMARY KEY(phone_no) ;

ALTER TABLE group_name ADD CONSTRAINT group_name_pk  PRIMARY KEY(id);

ALTER TABLE member ADD CONSTRAINT menber_fk1 
  FOREIGN KEY(phone_no) REFERENCES contacts(phone_no) ON DELETE CASCADE;
ALTER TABLE member ADD CONSTRAINT member_fk2 
  FOREIGN KEY(id) REFERENCES group_name(id) ON DELETE CASCADE;

insert into contacts(name, phone_no) values ('nabila', '01929665165');
insert into contacts(name, phone_no) values ('ammu', '01924332895');  
insert into contacts(name, phone_no) values ('abbu', '01929665190');
insert into contacts(name, phone_no) values ('tajin', '01924332890');  
 insert into contacts(name, phone_no) values ('nisha', '01939665165');
insert into contacts(name, phone_no) values ('nadia', '01934332895'); 


insert into phone(phone_no) values('01929665165');
insert into phone(phone_no) values('01929665190');
insert into phone(phone_no) values('01939665165');  

insert into sim(phone_no) values('01934332895');  
insert into sim(phone_no) values('01924332890');
insert into sim(phone_no) values('01924332895');  
  
insert into group_name(id, grp_name)  values(1, 'grp 1');
insert into group_name(id, grp_name)  values(2, 'grp 2');
  

insert into member(phone_no, id) values('01929665165',1);
insert into member(phone_no, id) values('01929665190',1);
insert into member(phone_no, id) values('01924332890',2);
insert into member(phone_no, id) values('01934332895',2);
insert into member(phone_no, id) values('01939665165',2);  


/*   LAB 10 ------>   COMMIT, SAVEPOINT             */
commit;
savepoint point_1;




  