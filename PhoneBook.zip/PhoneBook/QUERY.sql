DROP TRIGGER edit_trg;
drop FUNCTION find_member;

/*         LAB 4 ------>  ORDER BY NAME AND PHONE_NO    USING ORDER BY CLAUSE      */
SELECT name, phone_no FROM contacts ORDER BY name;
SELECT name, phone_no FROM contacts ORDER BY phone_no;


/*     LAB 5 ------>  SELECT GROUP , NAME , CONTACT NO. IN ALL GROUPS USING NESTED QUERY   */
 SELECT group_name.grp_name , name , phone_no
FROM ( SELECT member.id i, contacts.name, contacts.phone_no
       FROM contacts ,member
        WHERE contacts.phone_no = member.phone_no) , group_name
WHERE group_name.id = i ;     


/* LAB 6 --- > select group name , name and phone no. from all group using natural join */


SELECT id, grp_name, contacts.name , phone_no
FROM ( SELECT id, group_name.grp_name, member.phone_no
       FROM group_name JOIN member
        USING (id) ) JOIN contacts
using(phone_no);

/*        LAB 6 ----> FINDING WHICH PHONE NUMBERS ARE NOT IN ANY GROUP */

SELECT grp_name, phone_no
FROM ( SELECT id, group_name.grp_name, member.phone_no
       FROM group_name JOIN member
        USING (id) )  right outer join contacts
USING(phone_no);


/*         LAB 6 ------> select group name, name and phone no. of a  certain group using join, NESTED SUBQUERY */


SELECT id, grp_name, contacts.name , phone_no
FROM ( SELECT group_name.id, group_name.grp_name, member.phone_no
       FROM group_name , member
        where group_name.id = member.id and grp_name=&x) JOIN contacts
USING(phone_no);

/*         SELECT NAME AND PHONE NO. IN A GROUP USING CURSOR      */

SET SERVEROUTPUT ON
DECLARE
     CURSOR cr IS SELECT contacts.name, member.phone_no FROM contacts, member, group_name 
      WHERE contacts.phone_no=member.phone_no and group_name.id = member.id and group_name.grp_name='grp 1';
  b cr%ROWTYPE;

BEGIN
OPEN cr;
 LOOP
    FETCH cr INTO b;
    EXIT WHEN cr%NOTFOUND;
    dbms_output.put_line(b.name||'   '||b.phone_no);
 END LOOP;
CLOSE cr;  
END;
/ 


 /*
 SELECT contacts.name , group_name.grp_name, member.phone_no
 FROM group_name, member, contacts
 where group_name.id = member.id and grp_name = 'grp 2' and member.phone_no = contacts.phone_no;

 */


/*     LAB 7 ----> INSERT PHONE NUMBER, NAME USING BLOCK    */
set SERVEROUTPUT on
DECLARE
  NAME varchar(20);
  PHONE_NO varchar(15);
  STORAGE varchar(8);

BEGIN
  NAME:= &NAME;
  PHONE_NO:=&PHONE_NO;
  STORAGE:=&STORAGE;

insert into contacts(name,phone_no) values(NAME,PHONE_NO);
if STORAGE = 'phone' then insert into phone(phone_no) values(PHONE_NO);
else insert into sim(phone_no) values(PHONE_NO);
end if;
END;
/


/*          DELETE MEMBER FROM GROUP USING BLOCK */ 
DECLARE 
  NAME contacts.name%type;
BEGIN
 DELETE FROM member WHERE phone_no = (SELECT phone_no from contacts WHERE name = &contact_name);
END;
/ 

/*    LAB 7 -------> DELETE CONTACT NUMBER USING BLOCK, NESTED BLOCK        */

DECLARE
 TEMP contacts.phone_no%type;
 N contacts.name%type;
BEGIN 
dbms_output.put_line('Select a name to delete from contact list ');
  N := &NAME;
   BEGIN
      select phone_no into TEMP from contacts where name = N;
   
    END;
DELETE  FROM contacts WHERE name = N;
DELETE FROM sim WHERE phone_no = TEMP;
DELETE FROM phone WHERE phone_no = TEMP;
DELETE FROM member WHERE phone_no = TEMP;
END;
/


/*       LAB 7 EDIT CONTACT NAME AND GROUP NAME            */

SET SERVEROUTPUT ON
DECLARE
 old_name group_name.grp_name%type;
 new_name group_name.grp_name%type;
 choice group_name.grp_name%type;
BEGIN
 dbms_output.put_line('Write "grp_name" to change group name');
 dbms_output.put_line('Write "contact_name" to change contact name' );
  choice:= &option; 
  old_name:= &old_name;
  new_name:=&new_name;

IF choice = 'grp_name' THEN 
UPDATE group_name set grp_name = new_name WHERE grp_name = old_name;
ELSE  
   IF choice = 'contact_name' THEN
        UPDATE contacts set name = new_name WHERE name = old_name; 
   ELSE 
        dbms_output.put_line('Invalid operation');
    END IF;
END if;
END;
/


    /* LAB 4, 8 ---->   COUNT   MEMBER  OF A GROUP USING FUNCTION */

CREATE OR REPLACE FUNCTION find_member(input IN group_name.grp_name%type) RETURN NUMBER IS 
    cnt NUMBER;
BEGIN
  select count(member.phone_no) into cnt from member,group_name WHERE group_name.grp_name = input AND member.id = group_name.id;
  RETURN cnt;  
END;
/

SET SERVEROUTPUT ON
 DECLARE
    input group_name.grp_name%type;
BEGIN
   input:= &x;
dbms_output.put_line('Number of member in given group is ' || find_member(input));
END;
/


/*     lab 8 --------> SEARCH CONTACT NUMBER USING FUNCTION     */

CREATE OR REPLACE FUNCTION search(contact_name contacts.name%type)  RETURN varchar 
IS PN contacts.phone_no%type;
BEGIN
   select phone_no into PN from contacts WHERE name = contact_name;

   RETURN PN;
END;
/
SET SERVEROUTPUT ON
DECLARE
contact_name contacts.name%type;
BEGIN
contact_name := &contact_name;
dbms_output.put_line(' Searched Phone Number is = ' || search(contact_name) );
END;
/ 


    /*END OF FUNCTION*/



/*    LAB 7 ---->  ADD MEMBER TO GROUP USING PROCEDURE         */

CREATE OR REPLACE PROCEDURE add_member( y contacts.name%type,  w group_name.grp_name%type) IS 
   z group_name.id%type;
   x contacts.phone_no%type;
BEGIN
      SELECT phone_no into x from contacts WHERE name = y;
        SELECT group_name.id into z from group_name WHERE grp_name = w;
  INSERT INTO member values(x, z);
END;
/

SET SERVEROUTPUT ON
DECLARE
 y  contacts.name%type;
 w group_name.grp_name%type;
BEGIN
dbms_output.put_line('Give contact name and group name to add ');
  y := &NAME;
  w := &GROUP_NAME;
  pr(y,w);
END;
/


/*        LAB 8 ----->  INSERT ADITIONAL INFORMATION USING PROCEDURE    */

CREATE OR REPLACE PROCEDURE add_aditional_info(
   E contacts.email%type,
   A contacts.address%type,
   PN contacts.phone_no%type) IS
BEGIN
UPDATE contacts set email =E, address = A 
 WHERE phone_no=PN;
END;
/

DECLARE
   EMAIL contacts.email%type;
   ADDRESS contacts.address%type;
   PHONE_NO contacts.phone_no%type; 
BEGIN 
  EMAIL:= &EMAIL;
  ADDRESS:= &ADDRESS;
  PHONE_NO := &PHONE_NO;

  add_aditional_info(EMAIL,ADDRESS,PHONE_NO);
END;
/

/*       DELETE GROUP USING PROCEDURE            */

CREATE OR REPLACE PROCEDURE delete_grp (x group_name.grp_name%type) IS
BEGIN 
  DELETE FROM group_name WHERE grp_name = x;
END;
/  

DECLARE 
  x group_name.grp_name%type;
BEGIN
 x:=&GROUP_NAME;
 delete_grp(x);
END;
/ 



/*  UPDATE PHONE NUMBER ON CONTACT TABLE WITH SIM AND PHONE STORAGE AS WELL AS MEMBER TABLE USING  TRIGGER */
 
CREATE OR REPLACE TRIGGER edit_trg
    BEFORE UPDATE OF phone_no ON contacts
    FOR EACH ROW 
BEGIN
      
   UPDATE phone P set  P.phone_no= :NEW.phone_no where P.phone_no = :OLD.phone_no;
   UPDATE sim S set  S.phone_no= :NEW.phone_no where S.phone_no = :OLD.phone_no;
   UPDATE member M set  M.phone_no= :NEW.phone_no where M.phone_no = :OLD.phone_no;
END;
/

UPDATE contacts SET phone_no = '' WHERE name = '';

 /*  END UPATING USSING TRIGGER */


/*       CREATE GROUP USING PROCEDURE AND TRIGGER    */

CREATE OR REPLACE TRIGGER add_grp
 BEFORE INSERT ON group_name FOR EACH ROW
DECLARE
 x int;
  BEGIN
    SELECT max(id) into x from group_name ;
    :NEW.id := x+1;

  END;
/

CREATE OR REPLACE PROCEDURE create_grp (x group_name.grp_name%type) IS
 cnt int;
BEGIN 
  SELECT count(id) into cnt FROM group_name WHERE grp_name=x;
  IF cnt>0 THEN
   dbms_output.put_line('GROUP NAME ALREADY EXISTS');
  ELSE
     INSERT into group_name(id, grp_name) values (0,x);
  END if;
END;
/  

DECLARE 
  x group_name.grp_name%type;
BEGIN
 x:=&GROUP_NAME;
 create_grp(x);
END;
/ 
















 